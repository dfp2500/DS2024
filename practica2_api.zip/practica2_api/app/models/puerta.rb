class Puerta < ApplicationRecord
end
