class PuertasController < ApplicationController
  def index
    #@puertas = Puerta.where(usuario: params[:usuario])
    @puertas = Puerta.all
    logger.info "Cargando puertas para usuario: #{params[:usuario]}, Total: #{@puertas.count}"
    render json: @puertas
  end

  def create
    @puerta = Puerta.new(puerta_params)
    if @puerta.save
      render json: @puerta, status: :created
    else
      render json: @puerta.errors, status: :unprocessable_entity
    end
  end

  def update
    @puerta = Puerta.find(params[:id])
    if @puerta.update(puerta_params)
      render json: @puerta
    else
      render json: @puerta.errors, status: :unprocessable_entity
    end
  end

  def destroy
    puerta = Puerta.find(params[:id])
    if puerta.destroy
      head :ok
    else
      render json: { error: "Failed to delete" }, status: :unprocessable_entity
    end
  end

  private

  def puerta_params
    params.require(:puerta).permit(:nombre, :material, :cerradura, :pinchos, :barricada, :usuario)
  end
end

