class CreatePuerta < ActiveRecord::Migration[7.1]
  def change
    create_table :puerta do |t|
      t.string :nombre
      t.string :material
      t.integer :cerradura
      t.integer :pinchos
      t.integer :barricada
      t.string :usuario

      t.timestamps
    end
  end
end
