require "test_helper"

class PuertumTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
